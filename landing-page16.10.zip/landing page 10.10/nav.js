class App extends React.Component{
  render(){
    return(
      <div>
      <header>
        <div className="logo">
          <h1>Logologo</h1>
        </div>
        <input type="checkbox" id="nav-toggle" className="nav-toggle" ></input>
        <label for="nav-toggle" className = "nav-toggle-label">
          <span className="label-span"></span>
        </label>
        <nav>
          <ul>
            <li><a>Recepient</a></li>
            <li><a>Profile</a></li>
            <li><a>Office</a></li>
          </ul>
        </nav>
      </header>
        <div class="content">
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('NavBar')
);
